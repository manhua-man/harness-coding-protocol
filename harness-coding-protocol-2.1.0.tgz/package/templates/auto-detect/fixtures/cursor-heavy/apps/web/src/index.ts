export const cursorHeavy = true;
